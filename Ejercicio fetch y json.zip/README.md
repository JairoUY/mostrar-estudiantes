# Despliega el JSON!

Deberán modificar el código que se encuentra en el archivo *js/script.js* para que al momento de cargar la página, muestre nombre y apellido de los estudiantes cargados en *json/data.json*.

Importante: Para poder realizar fetch al archivo JSON se debe ejecutar el código con la extensión LiveServer.